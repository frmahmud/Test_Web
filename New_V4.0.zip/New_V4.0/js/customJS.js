
//
function setupFiltering(checkboxId, sectionId) {
    const checkbox = document.getElementById(checkboxId);
    const section = document.getElementById(sectionId);

    // Only run the code if BOTH the checkbox and section are found on the page
    if (checkbox && section) {
        checkbox.addEventListener('change', function() {
            section.style.display = this.checked ? "block" : "none";
        });
        
        // Run once on load to set initial state
        section.style.display = checkbox.checked ? "block" : "none";
    }
}

// This will work for Auto-Logistics page
setupFiltering('check-auto', 'section-auto');
setupFiltering('check-logistics', 'section-logistics');

// This will work for Garden-Appliances page
setupFiltering('check-garden', 'section-garden');
setupFiltering('check-appliances', 'section-appliances');

// This will work for Professional-Education page
setupFiltering('check-professional', 'section-professional');
setupFiltering('check-education', 'section-education');

// This will work for Shopping-Leisure page
setupFiltering('check-retails', 'section-retails');
setupFiltering('check-food', 'section-food');
setupFiltering('check-travel', 'section-travel');
setupFiltering('check-pet', 'section-pet');

// This will work for Construction-Renovation page
setupFiltering('check-construction', 'section-construction');
setupFiltering('check-renovation', 'section-renovation');

// This will work for Shopping-Leisure page
setupFiltering('check-medical', 'section-medical');
setupFiltering('check-beauty', 'section-beauty');
setupFiltering('check-laundry', 'section-laundry');