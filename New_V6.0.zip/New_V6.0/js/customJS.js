//
function setupFiltering(checkboxId, sectionId) {
    const checkbox = document.getElementById(checkboxId);
    const section = document.getElementById(sectionId);

    // Only run the code if BOTH the checkbox and section are found on the page
    if (checkbox && section) {
        checkbox.addEventListener('change', function() {
            section.style.display = this.checked ? "block" : "none";
        });
        
        // Run once on load to set initial state
        section.style.display = checkbox.checked ? "block" : "none";
    }
}

// This will work for Auto-Logistics page
setupFiltering('check-auto', 'section-auto');
setupFiltering('check-logistics', 'section-logistics');

// This will work for Garden-Appliances page
setupFiltering('check-garden', 'section-garden');
setupFiltering('check-appliances', 'section-appliances');

// This will work for Professional-Education page
setupFiltering('check-professional', 'section-professional');
setupFiltering('check-education', 'section-education');

// This will work for Shopping-Leisure page
setupFiltering('check-retails', 'section-retails');
setupFiltering('check-food', 'section-food');
setupFiltering('check-travel', 'section-travel');
setupFiltering('check-pet', 'section-pet');

// This will work for Construction-Renovation page
setupFiltering('check-construction', 'section-construction');
setupFiltering('check-renovation', 'section-renovation');

// This will work for Shopping-Leisure page
setupFiltering('check-medical', 'section-medical');
setupFiltering('check-beauty', 'section-beauty');
setupFiltering('check-laundry', 'section-laundry');

document.addEventListener('DOMContentLoaded', function() {
    
    // Refresh Cart UI on load
    refreshAllCartUI();

    // --- 2. PRODUCT DETAILS PAGE LOGIC ---
    const params = new URLSearchParams(window.location.search);
    const productId = params.get('id');
    
    if (typeof products !== 'undefined' && productId) {
        const product = products.find(p => p.id === productId);
        if (product) {
            document.getElementById('product-title').textContent = product.name;
            document.getElementById('product-price').textContent = `$${product.price.toFixed(2)}`;
            document.getElementById('product-sku').textContent = `SKU-${product.id.toUpperCase()}`;
            document.getElementById('product-category').textContent = product.category;
            document.getElementById('product-main-image').src = product.image;
            document.getElementById('full-product-description').textContent = product.fullDescription;
            document.getElementById('sample-download-link').href = product.sampleDownload;
            if(product.tags) document.getElementById('product-tags').textContent = product.tags.join(', ');

            
      // --- Data Overview table (tbody has the id) ---
      const dataOverviewTableBody = document.getElementById('data-overview-table');
      if (dataOverviewTableBody && Array.isArray(product.dataOverview)) {
        dataOverviewTableBody.innerHTML = ''; // Clear existing rows

        for (let i = 0; i < product.dataOverview.length; i += 2) {
          const left = product.dataOverview[i];
          const right = product.dataOverview[i + 1];

          const row = document.createElement('tr');
          row.innerHTML = `
            <td>${left?.type ?? ''}</td>
            <td>${left?.count ?? ''}</td>
            ${right
              ? `<td>${right.type ?? ''}</td><td>${right.count ?? ''}</td>`
              : `<td colspan="2"></td>`}
          `;
          dataOverviewTableBody.appendChild(row);
        }
      } else {
        console.warn('Data overview tbody not found or product.dataOverview missing.');
      }


            // Gallery Logic
            const productGallery = document.getElementById('product-gallery');
            const mainImage = document.getElementById('product-main-image');
            if (productGallery && mainImage) {
                productGallery.innerHTML = '';
                product.gallery.forEach((imgSrc, index) => {
                    const col = document.createElement('div');
                    col.className = 'col-3';
                    const img = document.createElement('img');
                    img.src = imgSrc;
                    img.className = `img-fluid product-thumbnail thumb-img ${index === 0 ? 'active' : ''}`;
                    img.style.cursor = 'pointer';
                    img.onclick = () => {
                        mainImage.src = imgSrc;
                        productGallery.querySelectorAll('.thumb-img').forEach(t => t.classList.remove('active'));
                        img.classList.add('active');
                    };
                    col.appendChild(img);
                    productGallery.appendChild(col);
                });
            }
        }
    }

    // --- 3. QUANTITY BUTTONS (FIXED: ONLY ONE LISTENER) ---
    document.addEventListener('click', function(e) {
        const btnPlus = e.target.closest('.quantity-right-plus');
        const btnMinus = e.target.closest('.quantity-left-minus');

        if (btnPlus || btnMinus) {
            e.preventDefault();
            const container = (btnPlus || btnMinus).closest('.product-qty') || (btnPlus || btnMinus).closest('.product-item');
            const qtyInput = container.querySelector('input[name="quantity"]') || container.querySelector('.input-number');
            if (qtyInput) {
                let val = parseInt(qtyInput.value) || 1;
                qtyInput.value = btnPlus ? val + 1 : (val > 1 ? val - 1 : 1);
            }
        }
    });

    // --- 4. ADD TO CART BUTTONS (STAY ON PAGE + NOTIFICATION) ---
    document.querySelectorAll('[data-action="add-to-cart"]').forEach(btn => {
        btn.addEventListener('click', function(e) {
            e.preventDefault(); 
            
            const itemContainer = this.closest('.product-item') || document.body;
            const productId = this.getAttribute('data-product-id') || params.get('id');
            const qtyInput = itemContainer.querySelector('input[name="quantity"]') || itemContainer.querySelector('.input-number');
            const quantity = parseInt(qtyInput ? qtyInput.value : 1);
            
            const product = products.find(p => p.id === productId);
            if (product) {
                addToLocalStorage(product, quantity);
                refreshAllCartUI(); 

                // --- NEW: POPUP NOTIFICATION ---
                showToast(`${product.name} added to cart!`);
            }
        });
    });

    // Helper function for the popup
    function showToast(message) {
        // Create the notification element
        const toast = document.createElement('div');
        toast.textContent = message;
        
        // Style the notification
        Object.assign(toast.style, {
            position: 'fixed',
            bottom: '20px',
            right: '20px',
            backgroundColor: '#28a745',
            color: '#fff',
            padding: '12px 24px',
            borderRadius: '5px',
            zIndex: '9999',
            boxShadow: '0 4px 12px rgba(0,0,0,0.1)',
            fontFamily: 'sans-serif',
            transition: 'opacity 0.5s ease'
        });

        document.body.appendChild(toast);

        // Remove after 2 seconds
        setTimeout(() => {
            toast.style.opacity = '0';
            setTimeout(() => toast.remove(), 500);
        }, 2000);
    }

    // --- 5. CART HELPER FUNCTIONS ---
    function refreshAllCartUI() {
    const cart = JSON.parse(localStorage.getItem('cart')) || [];
    const iconBadge = document.getElementById('cart-icon-badge');
    
    if (iconBadge) {
        const totalItems = cart.length;
        iconBadge.textContent = totalItems;
        
        // If total is 0, hide the badge. If > 0, show it.
        if (totalItems > 0) {
            iconBadge.style.setProperty('display', 'flex', 'important');
        } else {
            iconBadge.style.display = 'none';
        }
    }

    if (document.getElementById('cart-items-body')) {
        renderMainCartTable();
    }
}
// --- 6. CLEAR FULL CART FUNCTION ---
window.clearFullCart = function() {
    if (confirm("Are you sure you want to remove all items from your cart?")) {
        // 1. Clear LocalStorage
        localStorage.removeItem('cart');
        
        // 2. Update the UI
        refreshAllCartUI();
        
        // 3. Optional: Show notification
        if (typeof showToast === "function") {
            showToast("Cart cleared successfully");
        }
    }
};

    function renderMainCartTable() {
    const cart = JSON.parse(localStorage.getItem('cart')) || [];
    const container = document.getElementById('cart-items-body');
    const subtotalEl = document.getElementById('cart-subtotal');
    const totalEl = document.getElementById('cart-total');
    let total = 0;

    if (cart.length === 0) {
        container.innerHTML = '<tr><td colspan="5" class="py-5 text-center text-muted">Your cart is empty.</td></tr>';
        if(subtotalEl) subtotalEl.textContent = "$0.00";
        if(totalEl) totalEl.textContent = "$0.00";
        return;
    }

    container.innerHTML = cart.map((item, index) => {
        const itemTotal = item.price * item.quantity;
        total += itemTotal;
        return `
            <tr>
                <td class="py-4 ps-4">
                    <div class="d-flex align-items-center">
                        <img src="${item.image}" class="img-fluid rounded border me-3" style="width: 60px; height: 60px; object-fit: cover;">
                        <div>
                            <h6 class="mb-0 fw-bold" style="color: #161615;">${item.name}</h6>
                        </div>
                    </div>
                </td>
                
                <td class="fw-semibold">$${item.price.toFixed(2)}</td>
                
                <td>
                    <div class="input-group input-group-sm" style="width: 110px;">
                        <button class="btn btn-outline-secondary fw-bold" onclick="updateQty(${index}, -1)">-</button>
                        <input type="text" class="form-control text-center fw-bold bg-white" value="${item.quantity}" readonly>
                        <button class="btn btn-outline-secondary fw-bold" onclick="updateQty(${index}, 1)">+</button>
                    </div>
                </td>
                
                <td class="text-end fw-bold">$${itemTotal.toFixed(2)}</td>
                
                <td class="text-center">
                    <button class="btn p-0 border-0 text-danger d-inline-flex align-items-center justify-content-center" 
                            onclick="removeItem(${index})" 
                            style="width: 32px; height: 32px; transition: transform 0.2s ease;">
                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                            <line x1="18" y1="6" x2="6" y2="18"></line>
                            <line x1="6" y1="6" x2="18" y2="18"></line>
                        </svg>
                    </button>
                </td>
            </tr>`;
    }).join('');

    if(subtotalEl) subtotalEl.textContent = `$${total.toFixed(2)}`;
    if(totalEl) totalEl.textContent = `$${total.toFixed(2)}`;
}

    function addToLocalStorage(product, qty) {
        let cart = JSON.parse(localStorage.getItem('cart')) || [];
        const idx = cart.findIndex(item => item.id === product.id);
        if (idx > -1) cart[idx].quantity += qty;
        else cart.push({ ...product, quantity: qty });
        localStorage.setItem('cart', JSON.stringify(cart));
    }

    window.updateQty = (index, change) => {
        let cart = JSON.parse(localStorage.getItem('cart'));
        cart[index].quantity += change;
        if (cart[index].quantity < 1) cart[index].quantity = 1;
        localStorage.setItem('cart', JSON.stringify(cart));
        refreshAllCartUI();
    };

    window.removeItem = (index) => {
        let cart = JSON.parse(localStorage.getItem('cart'));
        cart.splice(index, 1);
        localStorage.setItem('cart', JSON.stringify(cart));
        refreshAllCartUI();
    };
});