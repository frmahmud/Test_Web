// productData.js

const products = [
	//Auto-Logistics products
	//Auto-Servcies
    {
        id: "list-of-auto-electrical",
        name: "Auto Electrical Services",
        price: 1.00,
        image: "images/products/auto_logistics/auto_service/auto_electrical_services.png",
        category: "Auto Logistics",
        tags: ["Auto", "Repairs", "Electrical"],
        description: "A comprehensive directory of auto electrical specialists, providing essential contact details and location data for repairers and technicians nationwide.",
        fullDescription: "This product offers an extensive and verified database of auto electrical service providers across various regions. Each entry includes business names, physical addresses, direct contact numbers, email addresses (where available), and website URLs. The data is meticulously compiled to assist logistics managers, parts suppliers, and marketing professionals in connecting with the automotive electrical repair sector with precision and ease.",
		dataOverview: [
            { type: "Total Auto Electrical", count: "15,000+" },
            { type: "Contact Numbers", count: "12,000+" },
            { type: "Email Addresses", count: "8,000+" },
            { type: "Physical Addresses", count: "15,000+" },
            { type: "School Types", count: "Various" },
            { type: "Geographical Coverage", count: "National" }
        ],
        sampleDownload: "samples/sample-download/sample-auto-logistics/sample-auto/sample_auto_electrical_services.xlsx", // Placeholder for a real sample file
        gallery: [
            "images/products/auto_logistics/auto_service/auto_electrical_services.png",
            "samples/sample-download/sample-auto-logistics/sample-auto/sample_auto_electrical_services.png"
        ]
    },
	{
        id: "list-of-auto-parts",
        name: "Auto Parts Recyclers",
        price: 1.00,
        image: "images/products/auto_logistics/auto_service/auto_partrs_recy.png",
        category: "Auto Logistics",
        tags: ["Auto", "Repairs", "Parts"],
        description: "A complete database of auto parts recyclers and wreckers, including full contact information and facility locations for the automotive recycling industry.",
        fullDescription: "This dataset provides a detailed map of the auto parts recycling landscape. It contains up-to-date listings for recyclers and wrecking yards, featuring business names, addresses, phone numbers, and digital contact points. It is a vital resource for secondary parts retailers, environmental researchers, and automotive supply chain professionals looking for comprehensive industry coverage and verified lead data.",
		dataOverview: [
            { type: "Total Auto Parts Recyclers", count: "11,000+" },
            { type: "Contact Numbers", count: "3,000+" },
            { type: "Email Addresses", count: "7,000+" },
            { type: "Physical Addresses", count: "4,000+" },
            { type: "School Types", count: "Various" },
            { type: "Geographical Coverage", count: "National" }
        ],
        sampleDownload: "samples/sample-download/sample-auto-logistics/sample-auto/sample-auto-parts-recyclers.xlsx",
        gallery: [
            "images/products/auto_logistics/auto_service/auto_partrs_recy.png",
            "samples/sample-download/sample-auto-logistics/sample-auto/sample-auto-parts.png"
        ]
    },
	{
        id: "list-of-bicycle-accessories",
        name: "Bicycle Accessories",
        price: 1.00,
        image: "images/products/auto_logistics/auto_service/Bicy_acc_rep.png",
        category: "Auto Logistics",
        tags: ["Auto", "Repairs", "Parts"],
        description: "A complete database of auto parts recyclers and wreckers, including full contact information and facility locations for the automotive recycling industry.",
        fullDescription: "This dataset provides a detailed map of the auto parts recycling landscape. It contains up-to-date listings for recyclers and wrecking yards, featuring business names, addresses, phone numbers, and digital contact points. It is a vital resource for secondary parts retailers, environmental researchers, and automotive supply chain professionals looking for comprehensive industry coverage and verified lead data.",
		dataOverview: [
            { type: "Total Auto Parts Recyclers", count: "15,000+" },
            { type: "Contact Numbers", count: "12,000+" },
            { type: "Email Addresses", count: "8,000+" },
            { type: "Physical Addresses", count: "15,000+" },
            { type: "School Types", count: "Various" },
            { type: "Geographical Coverage", count: "National" }
        ],
        sampleDownload: "samples/sample-download/sample-auto-logistics/sample-auto/sample-bicycle-accessories.xlsx",
        gallery: [
            "images/products/auto_logistics/auto_service/Bicy_acc_rep.png",
            "samples/sample-download/sample-auto-logistics/sample-auto/sample-bicycle-accessories.png"
        ]
    },
	{
        id: "list-of-motor-engineers",
        name: "Motor Engineers Repairs",
        price: 1.00,
        image: "images/products/auto_logistics/auto_service/motor_eng.png",
        category: "Auto Logistics",
        tags: ["Auto", "Repairs", "Parts"],
        description: "A complete database of auto parts recyclers and wreckers, including full contact information and facility locations for the automotive recycling industry.",
        fullDescription: "This dataset provides a detailed map of the auto parts recycling landscape. It contains up-to-date listings for recyclers and wrecking yards, featuring business names, addresses, phone numbers, and digital contact points. It is a vital resource for secondary parts retailers, environmental researchers, and automotive supply chain professionals looking for comprehensive industry coverage and verified lead data.",
		dataOverview: [
            { type: "Total Auto Parts Recyclers", count: "15,000+" },
            { type: "Contact Numbers", count: "12,000+" },
            { type: "Email Addresses", count: "8,000+" },
            { type: "Physical Addresses", count: "15,000+" },
            { type: "School Types", count: "Various" },
            { type: "Geographical Coverage", count: "National" }
        ],
        sampleDownload: "samples/sample-download/sample-auto-logistics/sample-auto/sample-motor-engineers.xlsx",
        gallery: [
            "images/products/auto_logistics/auto_service/motor_eng.png",
            "samples/sample-download/sample-auto-logistics/sample-auto/sample-motor-engineers.png"
        ]
    },
	{
        id: "list-of-panel_beaters",
        name: "Panel Beaters Painters",
        price: 1.00,
        image: "images/products/auto_logistics/auto_service/panel_beat.png",
        category: "Auto Logistics",
        tags: ["Auto", "Repairs", "Parts"],
        description: "A complete database of auto parts recyclers and wreckers, including full contact information and facility locations for the automotive recycling industry.",
        fullDescription: "This dataset provides a detailed map of the auto parts recycling landscape. It contains up-to-date listings for recyclers and wrecking yards, featuring business names, addresses, phone numbers, and digital contact points. It is a vital resource for secondary parts retailers, environmental researchers, and automotive supply chain professionals looking for comprehensive industry coverage and verified lead data.",
		dataOverview: [
            { type: "Total Auto Parts Recyclers", count: "15,000+" },
            { type: "Contact Numbers", count: "12,000+" },
            { type: "Email Addresses", count: "8,000+" },
            { type: "Physical Addresses", count: "15,000+" },
            { type: "School Types", count: "Various" },
            { type: "Geographical Coverage", count: "National" }
        ],
        sampleDownload: "samples/sample-download/sample-auto-logistics/sample-auto/sample-panel-beaters.xlsx",
        gallery: [
            "images/products/auto_logistics/auto_service/panel_beat.png",
            "samples/sample-download/sample-auto-logistics/sample-auto/sample-panel-beaters.png"
        ]
    },
	{
        id: "list-of-towing-services",
        name: "Towing Services",
        price: 1.00,
        image: "images/products/auto_logistics/auto_service/towing.png",
        category: "Auto Logistics",
        tags: ["Auto", "Repairs", "Parts"],
        description: "A complete database of auto parts recyclers and wreckers, including full contact information and facility locations for the automotive recycling industry.",
        fullDescription: "This dataset provides a detailed map of the auto parts recycling landscape. It contains up-to-date listings for recyclers and wrecking yards, featuring business names, addresses, phone numbers, and digital contact points. It is a vital resource for secondary parts retailers, environmental researchers, and automotive supply chain professionals looking for comprehensive industry coverage and verified lead data.",
		dataOverview: [
            { type: "Total Auto Parts Recyclers", count: "15,000+" },
            { type: "Contact Numbers", count: "12,000+" },
            { type: "Email Addresses", count: "8,000+" },
            { type: "Physical Addresses", count: "15,000+" },
            { type: "School Types", count: "Various" },
            { type: "Geographical Coverage", count: "National" }
        ],
        sampleDownload: "samples/sample-download/sample-auto-logistics/sample-auto/sample-towing-services.xlsx",
        gallery: [
            "images/products/auto_logistics/auto_service/towing.png",
            "samples/sample-download/sample-auto-logistics/sample-auto/sample-towing-services.png"
        ]
    },
	{
        id: "list-of-tyres-retail",
        name: "Tyres Retail",
        price: 1.00,
        image: "images/products/auto_logistics/auto_service/sample-tyres-retailt.png",
        category: "Auto Logistics",
        tags: ["Auto", "Repairs", "Parts"],
        description: "A complete database of auto parts recyclers and wreckers, including full contact information and facility locations for the automotive recycling industry.",
        fullDescription: "This dataset provides a detailed map of the auto parts recycling landscape. It contains up-to-date listings for recyclers and wrecking yards, featuring business names, addresses, phone numbers, and digital contact points. It is a vital resource for secondary parts retailers, environmental researchers, and automotive supply chain professionals looking for comprehensive industry coverage and verified lead data.",
		dataOverview: [
            { type: "Total Auto Parts Recyclers", count: "15,000+" },
            { type: "Contact Numbers", count: "12,000+" },
            { type: "Email Addresses", count: "8,000+" },
            { type: "Physical Addresses", count: "15,000+" },
            { type: "School Types", count: "Various" },
            { type: "Geographical Coverage", count: "National" }
        ],
        sampleDownload: "samples/sample-download/sample-auto-logistics/sample-auto/sample-auto-parts-recyclers.xlsx",
        gallery: [
            "images/products/auto_logistics/auto_service/tyre-ret.png",
            "samples/sample-download/sample-auto-logistics/sample-auto/sample-tyres-retail.png"
        ]
    },
	{
        id: "list-of-windscreens",
        name: "Windscreens Repairs",
        price: 1.00,
        image: "images/products/auto_logistics/auto_service/wind_re.png",
        category: "Auto Logistics",
        tags: ["Auto", "Repairs", "Parts"],
        description: "A complete database of auto parts recyclers and wreckers, including full contact information and facility locations for the automotive recycling industry.",
        fullDescription: "This dataset provides a detailed map of the auto parts recycling landscape. It contains up-to-date listings for recyclers and wrecking yards, featuring business names, addresses, phone numbers, and digital contact points. It is a vital resource for secondary parts retailers, environmental researchers, and automotive supply chain professionals looking for comprehensive industry coverage and verified lead data.",
		dataOverview: [
            { type: "Total Auto Parts Recyclers", count: "15,000+" },
            { type: "Contact Numbers", count: "12,000+" },
            { type: "Email Addresses", count: "8,000+" },
            { type: "Physical Addresses", count: "15,000+" },
            { type: "School Types", count: "Various" },
            { type: "Geographical Coverage", count: "National" }
        ],
        sampleDownload: "samples/sample-download/sample-auto-logistics/sample-auto/sample-windscreens-repairs.xlsx",
        gallery: [
            "images/products/auto_logistics/auto_service/wind_re.png",
            "samples/sample-download/sample-auto-logistics/sample-auto/sample-windscreens-repairs.png"
        ]
    },
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
    {
        id: "list-of-beauty-salons",
        name: "List of Beauty Salons",
        price: 98.00,
        image: "images/product-item2.jpg",
        category: "Beauty & Personal Care",
        tags: ["beauty", "salons", "spa", "hair"],
        description: "A detailed directory of beauty salons, including services offered, contact details, and locations. Perfect for beauty product suppliers or service aggregators.",
        fullDescription: "This product offers an extensive list of beauty salons, hair salons, nail salons, and spas. Each listing provides the salon's name, address, phone number, website, and a brief overview of services. It's an excellent resource for beauty product distributors, marketing agencies, or individuals seeking comprehensive information on beauty service providers in a specific area.",
        dataOverview: [
            { type: "Total Salons", count: "10,000+" },
            { type: "Contact Numbers", count: "9,500+" },
            { type: "Website Links", count: "7,000+" },
            { type: "Physical Addresses", count: "10,000+" },
            { type: "Service Types", count: "Hair, Nails, Spa, etc." },
            { type: "Geographical Coverage", count: "National" }
        ],
        sampleDownload: "samples/sample-beauty-salons.xlsx",
        gallery: [
            "images/product-item2.jpg",
            "samples/sample-beauty-salons.jpg"
        ]
    },
    {
        id: "list-of-doctors",
        name: "List of Doctors",
        price: 98.00,
        image: "images/product-item3.jpg",
        category: "Medical Services",
        tags: ["doctors", "medical", "healthcare", "clinics"],
        description: "A comprehensive database of medical practitioners, including specialties, clinic addresses, and contact information. Ideal for healthcare providers and medical suppliers.",
        fullDescription: "This product contains a vast compilation of doctors and medical professionals, categorized by their specialties (e.g., General Practitioner, Pediatrician, Dermatologist). Each entry includes the doctor's name, clinic address, contact number, and professional affiliations. This data is invaluable for medical device companies, pharmaceutical sales, or patients looking for specific medical services.",
        dataOverview: [
            { type: "Total Doctors", count: "20,000+" },
            { type: "Specialties Covered", count: "50+" },
            { type: "Clinic Addresses", count: "18,000+" },
            { type: "Contact Numbers", count: "19,000+" },
            { type: "Hospital Affiliations", count: "Partial" },
            { type: "Geographical Coverage", count: "National" }
        ],
        sampleDownload: "samples/sample-doctors.xlsx",
        gallery: [
            "images/product-item3.jpg",
            "samples/sample-doctors.jpg"
        ]
    },
    {
        id: "list-of-glazier-services",
        name: "List of Glazier & Glass Replacement Services",
        price: 98.00,
        image: "images/product-item4.jpg",
        category: "Home Improvement",
        tags: ["glazier", "glass", "repair", "home services"],
        description: "Directory of glazier and glass replacement services, with contact details and service areas. Useful for property management or construction businesses.",
        fullDescription: "This product provides a comprehensive list of glazier and glass replacement services. Each entry includes company name, contact information, address, and service specializations (e.g., residential, commercial, auto glass). This is a vital resource for property managers, insurance companies, or individuals needing glass repair services.",
        dataOverview: [
            { type: "Total Services", count: "5,000+" },
            { type: "Contact Numbers", count: "4,800+" },
            { type: "Service Areas", count: "Various" },
            { type: "Physical Addresses", count: "5,000+" },
            { type: "Specializations", count: "Residential, Commercial, Auto" },
            { type: "Geographical Coverage", count: "National" }
        ],
        sampleDownload: "samples/sample-glazier.pdf",
        gallery: [
            "images/product-item4.jpg",
            "https://placehold.co/600x400/E0E0E0/000000?text=Glazier+Sample+1"
        ]
    },
    {
        id: "air-conditioning-services",
        name: "Air Conditioning Installation & Service",
        price: 98.00,
        image: "images/product-item5.jpg",
        category: "Home Improvement",
        tags: ["AC", "air conditioning", "HVAC", "home services"],
        description: "A list of air conditioning installation and service providers, including their contact information and service details. Great for property owners or maintenance companies.",
        fullDescription: "This product offers a detailed list of air conditioning installation and service providers. Each entry includes the company name, contact details, address, and types of services offered (e.g., installation, repair, maintenance, commercial, residential). This data is highly useful for property management companies, real estate agencies, or anyone in need of HVAC services.",
        dataOverview: [
            { type: "Total Services", count: "7,000+" },
            { type: "Contact Numbers", count: "6,500+" },
            { type: "Service Types", count: "Installation, Repair, Maintenance" },
            { type: "Physical Addresses", count: "7,000+" },
            { type: "Brands Serviced", count: "Various" },
            { type: "Geographical Coverage", count: "National" }
        ],
        sampleDownload: "samples/sample-ac-services.pdf",
        gallery: [
            "images/product-item5.jpg",
            "https://placehold.co/600x400/E0E0E0/000000?text=AC+Service+Sample+1"
        ]
    },
    {
        id: "builders-contractors",
        name: "Builders & Building Contractors",
        price: 98.00,
        image: "images/product-item1.jpg",
        category: "Construction Services",
        tags: ["builders", "contractors", "construction", "renovation"],
        description: "A comprehensive list of builders and building contractors, with contact information and specializations. Essential for real estate developers and homeowners.",
        fullDescription: "This product provides an extensive directory of builders and building contractors, covering various specializations such as residential, commercial, and renovation projects. Each entry includes the company name, contact details, address, and a summary of their expertise. This is an indispensable resource for real estate developers, architects, and individuals planning construction or renovation projects.",
        dataOverview: [
            { type: "Total Builders", count: "12,000+" },
            { type: "Contact Numbers", count: "11,000+" },
            { type: "Specializations", count: "Residential, Commercial, Renovation" },
            { type: "Physical Addresses", count: "12,000+" },
            { type: "Years in Business", count: "Varied" },
            { type: "Geographical Coverage", count: "National" }
        ],
        sampleDownload: "samples/sample-builders.pdf",
        gallery: [
            "images/product-item1.jpg",
            "https://placehold.co/600x400/E0E0E0/000000?text=Builders+Sample+1",
            "https://placehold.co/600x400/D0D0D0/000000?text=Builders+Sample+2"
        ]
    },
    {
        id: "cabinet-makers",
        name: "Cabinet Makers & Designers",
        price: 98.00,
        image: "images/product-item2.jpg",
        category: "Home Improvement",
        tags: ["cabinets", "kitchen", "design", "woodwork"],
        description: "Directory of cabinet makers and designers, including contact information and design specializations. Useful for interior designers and homeowners.",
        fullDescription: "This product offers a detailed list of cabinet makers and designers, including those specializing in kitchen cabinets, custom cabinetry, and built-in furniture. Each entry provides the business name, contact information, address, and a description of their design style and materials used. This is a valuable resource for interior designers, contractors, and homeowners looking for custom cabinetry solutions.",
        dataOverview: [
            { type: "Total Makers", count: "4,000+" },
            { type: "Contact Numbers", count: "3,800+" },
            { type: "Design Specializations", count: "Modern, Traditional, Custom" },
            { type: "Physical Addresses", count: "4,000+" },
            { type: "Materials Used", count: "Wood, Laminate, etc." },
            { type: "Geographical Coverage", count: "National" }
        ],
        sampleDownload: "samples/sample-cabinet-makers.pdf",
        gallery: [
            "images/product-item2.jpg",
            "https://placehold.co/600x400/E0E0E0/000000?text=Cabinet+Sample+1",
            "https://placehold.co/600x400/D0D0D0/000000?text=Cabinet+Sample+2"
        ]
    },
    {
        id: "carpenters-joiners",
        name: "Carpenters & Joiners",
        price: 98.00,
        image: "images/product-item5.jpg",
        category: "Construction Services",
        tags: ["carpenters", "joiners", "woodworking", "construction"],
        description: "List of carpenters and joiners, with contact details and service offerings. Ideal for construction projects and home renovations.",
        fullDescription: "This product provides a comprehensive list of carpenters and joiners, detailing their expertise in various woodworking projects, from framing and roofing to custom furniture and intricate joinery. Each entry includes the professional's name or company, contact information, and a summary of their services. This is an essential resource for construction companies, renovation specialists, and homeowners seeking skilled woodworking professionals.",
        dataOverview: [
            { type: "Total Professionals", count: "8,000+" },
            { type: "Contact Numbers", count: "7,500+" },
            { type: "Service Offerings", count: "Framing, Finishing, Custom Work" },
            { type: "Physical Addresses", count: "8,000+" },
            { type: "Project Types", count: "Residential, Commercial" },
            { type: "Geographical Coverage", count: "National" }
        ],
        sampleDownload: "samples/sample-carpenters.pdf",
        gallery: [
            "images/product-item5.jpg",
            "https://placehold.co/600x400/E0E0E0/000000?text=Carpenter+Sample+1",
            "https://placehold.co/600x400/D0D0D0/000000?text=Carpenter+Sample+2"
        ]
    },
    {
        id: "pink-watch",
        name: "Pink Watch",
        price: 870.00,
        image: "images/product-item1.jpg",
        category: "Smart Watches",
        tags: ["watch", "pink", "smart", "wearable"],
        description: "A stylish pink smartwatch with advanced features.",
        fullDescription: "The Pink Watch combines elegant design with cutting-edge technology. It features a vibrant pink strap, a high-resolution display, and a suite of smart functionalities including heart rate monitoring, step tracking, and notification alerts. It's water-resistant and offers a long-lasting battery, making it perfect for daily wear and fitness enthusiasts.",
        dataOverview: [
            { type: "Color", count: "Pink" },
            { type: "Display Type", count: "AMOLED" },
            { type: "Battery Life", count: "7 days" },
            { type: "Water Resistance", count: "5 ATM" },
            { type: "Sensors", count: "Heart Rate, Accelerometer" },
            { type: "Connectivity", count: "Bluetooth 5.0" }
        ],
        sampleDownload: "samples/sample-watch-specs.pdf",
        gallery: [
            "images/product-item1.jpg",
            "https://placehold.co/600x400/FFC0CB/000000?text=Pink+Watch+Side",
            "https://placehold.co/600x400/FFB6C1/000000?text=Pink+Watch+Back"
        ]
    },
    {
        id: "heavy-watch",
        name: "Heavy Watch",
        price: 680.00,
        image: "images/product-item7.jpg",
        category: "Smart Watches",
        tags: ["watch", "heavy", "durable", "sport"],
        description: "A robust and heavy-duty smartwatch designed for extreme conditions.",
        fullDescription: "The Heavy Watch is built for durability and performance. Its rugged design and reinforced casing make it ideal for outdoor adventures and demanding environments. It includes GPS, a barometer, and extended battery life, ensuring reliability when you need it most. Despite its robust build, it maintains smart features for daily use.",
        dataOverview: [
            { type: "Weight", count: "150g" },
            { type: "Material", count: "Stainless Steel, Reinforced Polymer" },
            { type: "Battery Life", count: "14 days (GPS off)" },
            { type: "Water Resistance", count: "10 ATM" },
            { type: "Features", count: "GPS, Barometer, Altimeter" },
            { type: "Connectivity", count: "Bluetooth, ANT+" }
        ],
        sampleDownload: "samples/sample-watch-specs.pdf",
        gallery: [
            "images/product-item7.jpg",
            "https://placehold.co/600x400/A9A9A9/000000?text=Heavy+Watch+Front",
            "https://placehold.co/600x400/808080/000000?text=Heavy+Watch+Durability"
        ]
    },
    {
        id: "spotted-watch",
        name: "Spotted Watch",
        price: 750.00,
        image: "images/product-item1.jpg",
        category: "Smart Watches",
        tags: ["watch", "spotted", "fashion", "unique"],
        description: "A unique spotted design smartwatch for a distinctive look.",
        fullDescription: "The Spotted Watch stands out with its distinctive spotted pattern on the strap and bezel. It's a fashion-forward smartwatch that doesn't compromise on functionality. Enjoy all standard smart features, including fitness tracking and smart notifications, wrapped in a truly unique aesthetic. Perfect for those who want to express their individuality.",
        dataOverview: [
            { type: "Design", count: "Spotted Pattern" },
            { type: "Display", count: "OLED" },
            { type: "Battery Life", count: "5 days" },
            { type: "Compatibility", count: "iOS, Android" },
            { type: "Sensors", count: "Heart Rate, Gyroscope" },
            { type: "Special Feature", count: "Customizable Watch Faces" }
        ],
        sampleDownload: "samples/sample-watch-specs.pdf",
        gallery: [
            "images/product-item1.jpg",
            "https://placehold.co/600x400/ADD8E6/000000?text=Spotted+Watch+Detail",
            "https://placehold.co/600x400/87CEEB/000000?text=Spotted+Watch+Lifestyle"
        ]
    },
    {
        id: "black-watch",
        name: "Black Watch",
        price: 650.00,
        image: "images/product-item9.jpg",
        category: "Smart Watches",
        tags: ["watch", "black", "classic", "minimalist"],
        description: "A sleek and classic black smartwatch, perfect for any occasion.",
        fullDescription: "The Black Watch offers a timeless design with modern smart capabilities. Its minimalist black finish makes it versatile for both formal and casual wear. It includes essential features like activity tracking, sleep monitoring, and smartphone connectivity. A reliable and stylish choice for everyday use.",
        dataOverview: [
            { type: "Color", count: "Matte Black" },
            { type: "Case Material", count: "Aluminum" },
            { type: "Battery Life", count: "6 days" },
            { type: "Water Resistance", count: "3 ATM" },
            { type: "Features", count: "Activity Tracking, Sleep Monitor" },
            { type: "Display Size", count: "1.3 inches" }
        ],
        sampleDownload: "samples/sample-watch-specs.pdf",
        gallery: [
            "images/product-item9.jpg",
            "https://placehold.co/600x400/36454F/FFFFFF?text=Black+Watch+Angle",
            "https://placehold.co/600x400/2F4F4F/FFFFFF?text=Black+Watch+Display"
        ]
    },
    {
        id: "black-watch-2",
        name: "Black Watch 2",
        price: 750.00,
        image: "images/product-item10.jpg",
        category: "Smart Watches",
        tags: ["watch", "black", "sport", "advanced"],
        description: "An advanced black smartwatch with enhanced fitness tracking.",
        fullDescription: "The Black Watch 2 is an upgraded version offering more precise fitness tracking, including advanced heart rate zones and VO2 max estimation. Its sleek black design is complemented by a durable build, making it suitable for intense workouts and daily wear. It also features improved battery life and a brighter display for better outdoor visibility.",
        dataOverview: [
            { type: "Color", count: "Deep Black" },
            { type: "Sensors", count: "Advanced HR, GPS, SpO2" },
            { type: "Battery Life", count: "8 days" },
            { type: "Display", count: "Always-on AMOLED" },
            { type: "Durability", count: "Scratch-resistant glass" },
            { type: "Compatibility", count: "Universal" }
        ],
        sampleDownload: "samples/sample-watch-specs.pdf",
        gallery: [
            "images/product-item10.jpg",
            "https://placehold.co/600x400/1C1C1C/FFFFFF?text=Black+Watch+2+Fitness",
            "https://placehold.co/600x400/0A0A0A/FFFFFF?text=Black+Watch+2+Features"
        ]
    },
    {
        id: "green-watch",
        name: "Green Watch",
        price: 750.00,
        image: "images/product-item1.jpg",
        category: "Smart Watches",
        tags: ["watch", "green", "outdoor", "rugged"],
        description: "A rugged green smartwatch designed for outdoor enthusiasts.",
        fullDescription: "The Green Watch is built for the outdoors, featuring a durable green casing and a long-lasting battery. It comes equipped with outdoor-specific sensors like a compass and altimeter, making it an ideal companion for hiking, camping, and other adventures. Its vibrant display is easily readable in direct sunlight.",
        dataOverview: [
            { type: "Color", count: "Forest Green" },
            { type: "Material", count: "Durable Polymer" },
            { type: "Battery Life", count: "10 days" },
            { type: "Water Resistance", count: "5 ATM" },
            { type: "Outdoor Features", count: "Compass, Altimeter, Barometer" },
            { type: "Display Type", count: "Transflective" }
        ],
        sampleDownload: "samples/sample-watch-specs.pdf",
        gallery: [
            "images/product-item1.jpg",
            "https://placehold.co/600x400/228B22/FFFFFF?text=Green+Watch+Outdoor",
            "https://placehold.co/600x400/3CB371/FFFFFF?text=Green+Watch+Adventure"
        ]
    }
];
